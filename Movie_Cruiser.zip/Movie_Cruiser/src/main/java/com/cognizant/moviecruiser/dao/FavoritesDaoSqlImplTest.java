package com.cognizant.moviecruiser.dao;

public class FavoritesDaoSqlImplTest {

	public static void main(String[] args) {

	}
	
	public static void testAddFavoritesMovie() {

	}

	public static void testGetAllFavoritesMovies() {

	}

	public static void testRemoveFavoritesMovie() {

	}

}
